import argparse, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.db import Base, engine, SessionLocal
from app.schema import Tick
from app.deriv import fetch_history, parse_history

ap=argparse.ArgumentParser(); ap.add_argument('--symbol',default='R_75'); ap.add_argument('--count',type=int,default=5000); args=ap.parse_args()
Base.metadata.create_all(engine)
rows=parse_history(fetch_history(args.symbol,args.count),args.symbol)
with SessionLocal() as s:
    existing={x for (x,) in s.query(Tick.epoch).filter(Tick.symbol==args.symbol).all()}
    for r in rows:
        if r['epoch'] not in existing: s.add(Tick(**r))
    s.commit()
print(f'Inserted {sum(r["epoch"] not in existing for r in rows)} ticks for {args.symbol}')
