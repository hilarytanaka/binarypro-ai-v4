import os, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
symbols=[x.strip() for x in os.getenv('LIVE_SYMBOLS','R_75').split(',') if x.strip()]
horizons=[int(x) for x in os.getenv('HORIZONS','1,5,10,20').split(',')]
for symbol in symbols:
    for h in horizons:
        cmd=[sys.executable,str(root/'scripts/train_models.py'),'--symbol',symbol,'--horizon',str(h)]
        p=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
        print(f'=== {symbol} h={h} ===\n{p.stdout}\n{p.stderr}',flush=True)
