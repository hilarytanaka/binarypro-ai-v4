import argparse, sys
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.db import SessionLocal
from app.schema import Tick
from app.features import build_features, add_target
from app.modeling import load_model, calibrated_predict, metrics

ap=argparse.ArgumentParser(); ap.add_argument('--symbol',default='R_75'); ap.add_argument('--horizon',type=int,default=5); ap.add_argument('--target',default='rise_fall'); args=ap.parse_args()
with SessionLocal() as s: rows=s.query(Tick).filter(Tick.symbol==args.symbol).order_by(Tick.epoch).all()
df=pd.DataFrame([{'symbol':r.symbol,'epoch':r.epoch,'price':r.price,'last_digit':r.last_digit} for r in rows])
F,raw=build_features(df,100); ds=add_target(F,raw,args.horizon,args.target)
model=load_model(args.symbol,args.horizon,args.target)
if not model: raise SystemExit('Model not found. Train first.')
X=ds.drop(columns=['target','symbol']).astype(float).values; y=ds.target.astype(int).values
# Final 20% remains the holdout report.
n=len(X); start=int(n*.8); p=calibrated_predict(model['model'],model['calibrator'],X[start:])
print(metrics(y[start:],p))
