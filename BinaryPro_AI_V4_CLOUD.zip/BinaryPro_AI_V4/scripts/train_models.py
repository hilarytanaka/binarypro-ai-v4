import argparse, sys
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.db import SessionLocal
from app.schema import Tick
from app.features import build_features, add_target
from app.modeling import train_one

ap=argparse.ArgumentParser(); ap.add_argument('--symbol',default='R_75'); ap.add_argument('--horizon',type=int,default=5); ap.add_argument('--target',default='all'); args=ap.parse_args()
with SessionLocal() as s:
    rows=s.query(Tick).filter(Tick.symbol==args.symbol).order_by(Tick.epoch).all()
df=pd.DataFrame([{'symbol':r.symbol,'epoch':r.epoch,'price':r.price,'last_digit':r.last_digit} for r in rows])
if len(df)<1500: raise SystemExit('Need at least ~1500 ticks before training.')
F,raw=build_features(df,100)
targets=['rise_fall','over_under','even_odd','matches_differs'] if args.target=='all' else [args.target]
for target in targets:
    ds=add_target(F,raw,args.horizon,target)
    X=ds.drop(columns=['target','symbol']).astype(float).values; y=ds['target'].astype(int).values
    meta=train_one(X,y,'auto',args.symbol,args.horizon,target)
    print(meta)
