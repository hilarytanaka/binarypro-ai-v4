import asyncio, os, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.db import Base, engine, SessionLocal
from app.schema import Tick
from app.deriv import fetch_history, parse_history
from scripts.live_collector import collect_symbol

symbols=[x.strip() for x in os.getenv('LIVE_SYMBOLS','R_75').split(',') if x.strip()]
bootstrap=int(os.getenv('BOOTSTRAP_TICKS','20000'))


def count(symbol):
    with SessionLocal() as s:
        return s.query(Tick).filter(Tick.symbol==symbol).count()


def bootstrap_symbol(symbol):
    n=count(symbol)
    if n >= bootstrap:
        return n
    target=max(5000, bootstrap-n)
    try:
        rows=parse_history(fetch_history(symbol,target),symbol)
        with SessionLocal() as s:
            existing={x for (x,) in s.query(Tick.epoch).filter(Tick.symbol==symbol).all()}
            for r in rows:
                if r['epoch'] not in existing:
                    s.add(Tick(**r))
            s.commit()
    except Exception as e:
        print(f'bootstrap {symbol} failed: {e}', flush=True)
    return count(symbol)

async def main():
    Base.metadata.create_all(engine)
    for symbol in symbols:
        print(f'Bootstrap {symbol}: {bootstrap_symbol(symbol)} ticks', flush=True)
    # Keep one process simple and reliable: rotate symbols continuously.
    while True:
        for symbol in symbols:
            try:
                await collect_symbol(symbol, duration_seconds=55)
            except Exception as e:
                print(f'live collector {symbol} failed: {e}', flush=True)
            await asyncio.sleep(2)

if __name__=='__main__':
    asyncio.run(main())
