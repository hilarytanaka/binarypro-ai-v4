import argparse, asyncio, json, sys
from pathlib import Path
from datetime import datetime, timezone
import websockets
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.config import DERIV_WS_URL
from app.db import Base, engine, SessionLocal
from app.schema import Tick

async def collect_symbol(symbol, duration_seconds=None):
    Base.metadata.create_all(engine)
    started=asyncio.get_event_loop().time()
    async with websockets.connect(DERIV_WS_URL,ping_interval=20,ping_timeout=20) as ws:
        await ws.send(json.dumps({'ticks':symbol,'subscribe':1}))
        async for raw in ws:
            if duration_seconds is not None and asyncio.get_event_loop().time()-started >= duration_seconds:
                return
            m=json.loads(raw)
            if m.get('msg_type')!='tick': continue
            t=m['tick']; epoch=int(t['epoch']); price=float(t['quote'])
            digit=int(str(price).replace('.','')[-1])
            with SessionLocal() as s:
                if not s.query(Tick).filter(Tick.symbol==symbol,Tick.epoch==epoch).first():
                    s.add(Tick(symbol=symbol,epoch=epoch,timestamp=datetime.fromtimestamp(epoch,tz=timezone.utc),price=price,last_digit=digit)); s.commit()

async def main(symbol):
    while True:
        try: await collect_symbol(symbol)
        except Exception as e:
            print(e, flush=True); await asyncio.sleep(5)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--symbol',default='R_75'); args=ap.parse_args(); asyncio.run(main(args.symbol))
