# BinaryPro AI Analyzer V4

A serious research-grade upgrade of the BinaryPro/ProTrader-style binary-options market-structure analyzer.

## What is included

- PostgreSQL/TimescaleDB-ready tick database schema
- Historical Deriv tick collector using `ticks_history`
- Live Deriv tick collector using `ticks`
- Feature engineering from price, tick direction and last digit behaviour
- Separate targets for Rise/Fall, Over/Under, Even/Odd and Matches/Differs
- Multiple ML candidates using scikit-learn
- Time-ordered train/calibration/test splits
- Probability calibration using a dedicated calibration period
- Walk-forward out-of-sample evaluation
- Brier score, log loss, accuracy, precision, recall and calibration statistics
- Model artifacts + JSON model registry metadata
- FastAPI inference API
- ProTrader-style browser dashboard
- WAIT state when evidence/confidence/sample requirements are not met
- No hard-coded 80–99% accuracy claim

## Important

The application does **not** manufacture high probabilities. It reports measured model probabilities and calibration statistics from real data. Binary-options contract settlement and payout rules should be validated against the exact contract before any real-money use.

## Quick start with Docker

1. Install Docker Desktop/Engine.
2. Copy `.env.example` to `.env` and set a Deriv App ID if required by your account/API setup.
3. Start the database and app:

```bash
docker compose up --build
```

4. Open `http://localhost:8000`.

## Without Docker

Python 3.11+ is recommended.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

A PostgreSQL connection is expected for production-scale data. SQLite can be used for a quick development run by setting `DATABASE_URL` accordingly, but it is not the recommended large-tick database.

## Data collection

Historical collection example:

```bash
python scripts/backfill.py --symbol R_75 --count 50000
```

Run several batches or use `--start`/`--end` epoch ranges for larger datasets.

Live collector:

```bash
python scripts/live_collector.py --symbol R_75
```

## Train

```bash
python scripts/train_models.py --symbol R_75 --horizon 5
```

Targets supported:

- `rise_fall`
- `over_under`
- `even_odd`
- `matches_differs`

The trainer uses an ordered train/calibration/test split and saves the selected calibrated model under `models/`.

## Evaluate

```bash
python scripts/evaluate.py --symbol R_75 --horizon 5 --target rise_fall
```

The evaluation is strictly time ordered. It does not randomly shuffle ticks.

## Production direction

For a larger deployment, add:

- TimescaleDB hypertables and compression policies
- object storage for raw historical archives
- scheduled retraining
- MLflow model registry
- multiple symbols/horizons in parallel
- model drift monitoring
- payout-aware expected-value calculations
- a paper-trading audit trail before enabling any execution integration
