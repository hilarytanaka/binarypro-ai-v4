# BinaryPro AI Analyzer V4 — Cloud One-Click Edition

This edition is prepared for a cloud deployment workflow. The included `render.yaml` provisions the application, database, live data collector, and scheduled retraining as one Blueprint deployment.

Android users do not need Python or Docker on their phones. The only phone-side steps are getting the project into a GitHub repository and connecting that repository to the cloud deployment service.

The cloud architecture is:

`Chrome/Android → FastAPI dashboard → PostgreSQL → Deriv historical/live data → feature pipeline → calibrated ML models → out-of-sample metrics`

The database is standard PostgreSQL in the managed Render Blueprint. The application remains compatible with PostgreSQL/TimescaleDB; for very large production datasets, a dedicated TimescaleDB service can be substituted through `DATABASE_URL`.

## Deployment

See `DEPLOY_ANDROID.md`.

## Model integrity

V4 separates training, calibration/validation, and the final chronological holdout. Candidate model selection uses validation data rather than the final holdout. The holdout is used for reporting only.

No performance percentage is hard-coded as a claim. Real performance appears only after real historical data has been collected and models have been evaluated.
