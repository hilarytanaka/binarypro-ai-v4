#!/bin/sh
set -eu
python -m compileall app scripts
python - <<'PY'
import yaml
print('render.yaml syntax check requires PyYAML; skipped if unavailable')
PY
