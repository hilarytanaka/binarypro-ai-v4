"""Deriv public market-data client for BinaryPro AI."""

from __future__ import annotations
import json
from dataclasses import dataclass
from typing import AsyncIterator, Optional

import pandas as pd
import websockets

DERIV_WS_URL = "wss://ws.binaryws.com/websockets/v3"


@dataclass
class Candle:
    epoch: int
    open: float
    high: float
    low: float
    close: float

    def as_dict(self):
        return {
            "epoch": self.epoch,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
        }


class DerivMarketData:
    def __init__(self, symbol: str = "1HZ100V"):
        self.symbol = symbol

    async def _request(self, payload: dict) -> dict:
        async with websockets.connect(
            DERIV_WS_URL, ping_interval=20, ping_timeout=20, close_timeout=5
        ) as ws:
            await ws.send(json.dumps(payload))
            while True:
                data = json.loads(await ws.recv())
                if data.get("error"):
                    err = data["error"]
                    raise RuntimeError(err.get("message", "Deriv API error"))
                return data

    async def historical_candles(self, granularity: int = 60, count: int = 200) -> pd.DataFrame:
        """Fetch OHLC candles directly from Deriv's public market-data API."""
        response = await self._request({
            "ticks_history": self.symbol,
            "end": "latest",
            "count": int(count),
            "style": "candles",
            "granularity": int(granularity),
        })
        candles = response.get("candles", [])
        rows = []
        for c in candles:
            rows.append({
                "epoch": int(c["epoch"]),
                "open": float(c["open"]),
                "high": float(c["high"]),
                "low": float(c["low"]),
                "close": float(c["close"]),
            })
        return pd.DataFrame(rows, columns=["epoch", "open", "high", "low", "close"])

    async def live_ticks(self) -> AsyncIterator[dict]:
        """Yield public Deriv ticks continuously."""
        async with websockets.connect(
            DERIV_WS_URL, ping_interval=20, ping_timeout=20, close_timeout=5
        ) as ws:
            await ws.send(json.dumps({"ticks": self.symbol, "subscribe": 1}))
            while True:
                data = json.loads(await ws.recv())
                if data.get("error"):
                    err = data["error"]
                    raise RuntimeError(err.get("message", "Deriv API error"))
                tick = data.get("tick")
                if tick:
                    yield {
                        "epoch": int(tick["epoch"]),
                        "price": float(tick["quote"]),
                    }

    async def live_candles(self, granularity: int = 60) -> AsyncIterator[dict]:
        """Aggregate the live tick stream into OHLC candles."""
        current: Optional[Candle] = None
        async for tick in self.live_ticks():
            bucket = (tick["epoch"] // granularity) * granularity
            price = tick["price"]
            if current is None or bucket != current.epoch:
                if current is not None:
                    yield current.as_dict()
                current = Candle(bucket, price, price, price, price)
            else:
                current.high = max(current.high, price)
                current.low = min(current.low, price)
                current.close = price
            yield current.as_dict()


async def get_deriv_candles(symbol="1HZ100V", granularity=60, count=200):
    return await DerivMarketData(symbol).historical_candles(granularity, count)
