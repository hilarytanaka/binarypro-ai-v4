import numpy as np
import pandas as pd

TARGETS = ('rise_fall', 'over_under', 'even_odd', 'matches_differs')

def _entropy(x):
    counts = np.bincount(x.astype(int), minlength=10).astype(float)
    p = counts / max(counts.sum(), 1.0)
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())

def build_features(df: pd.DataFrame, window: int = 100):
    d = df.sort_values('epoch').reset_index(drop=True).copy()
    d['ret'] = d['price'].pct_change().replace([np.inf, -np.inf], np.nan).fillna(0)
    d['tick_change'] = d['price'].diff().fillna(0)
    d['direction'] = np.sign(d['tick_change']).fillna(0)
    d['digit_even'] = (d['last_digit'] % 2 == 0).astype(int)
    d['digit_over5'] = (d['last_digit'] > 5).astype(int)
    d['digit_under5'] = (d['last_digit'] < 5).astype(int)
    d['digit_is5'] = (d['last_digit'] == 5).astype(int)

    cols = {}
    for w in [5, 10, 20, 50, window]:
        cols[f'ret_mean_{w}'] = d['ret'].rolling(w).mean()
        cols[f'ret_std_{w}'] = d['ret'].rolling(w).std()
        cols[f'change_mean_{w}'] = d['tick_change'].rolling(w).mean()
        cols[f'up_ratio_{w}'] = (d['direction'] > 0).rolling(w).mean()
        cols[f'down_ratio_{w}'] = (d['direction'] < 0).rolling(w).mean()
        cols[f'even_ratio_{w}'] = d['digit_even'].rolling(w).mean()
        cols[f'over5_ratio_{w}'] = d['digit_over5'].rolling(w).mean()
        cols[f'under5_ratio_{w}'] = d['digit_under5'].rolling(w).mean()
        cols[f'match5_ratio_{w}'] = d['digit_is5'].rolling(w).mean()
        cols[f'digit_entropy_{w}'] = d['last_digit'].rolling(w).apply(_entropy, raw=True)
        cols[f'price_z_{w}'] = (d['price'] - d['price'].rolling(w).mean()) / d['price'].rolling(w).std().replace(0, np.nan)
        cols[f'momentum_{w}'] = d['price'].pct_change(w)
    f = pd.DataFrame(cols)
    f['digit'] = d['last_digit']
    f['direction_now'] = d['direction']
    f['symbol'] = d['symbol'].astype('category').cat.codes
    f = f.replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    # Keep aligned raw index so target construction can use future ticks.
    return f, d.loc[f.index].reset_index(drop=True)

def add_target(frame, raw, horizon, target):
    future = raw['price'].shift(-horizon)
    if target == 'rise_fall': y = (future > raw['price']).astype(int)
    elif target == 'over_under': y = (raw['last_digit'].shift(-horizon) > 5).astype(int)
    elif target == 'even_odd': y = (raw['last_digit'].shift(-horizon) % 2 == 0).astype(int)
    elif target == 'matches_differs': y = (raw['last_digit'].shift(-horizon) == raw['last_digit']).astype(int)
    else: raise ValueError(target)
    out = frame.copy(); out['target'] = y.values
    return out.iloc[:-horizon].reset_index(drop=True)
