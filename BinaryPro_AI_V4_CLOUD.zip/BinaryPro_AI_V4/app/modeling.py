import json
from datetime import datetime, timezone
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, brier_score_loss, log_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

MODEL_DIR = Path(__import__('os').getenv('MODEL_DIR', 'models'))
MODEL_DIR.mkdir(exist_ok=True)

def fit_calibrator(base_model, X_cal, y_cal):
    # A dedicated logistic calibrator over the model's logit score. This keeps
    # calibration strictly separated from the final holdout test period.
    p = np.clip(base_model.predict_proba(X_cal)[:,1], 1e-6, 1-1e-6)
    z = np.log(p/(1-p)).reshape(-1,1)
    cal = LogisticRegression(C=10.0, solver='lbfgs')
    cal.fit(z, y_cal)
    return cal

def calibrated_predict(base, cal, X):
    p = np.clip(base.predict_proba(X)[:,1], 1e-6, 1-1e-6)
    z = np.log(p/(1-p)).reshape(-1,1)
    return cal.predict_proba(z)[:,1]

def metrics(y, p, threshold=0.5):
    pred = (p >= threshold).astype(int)
    return {
      'n': int(len(y)),
      'accuracy': float(accuracy_score(y,pred)),
      'precision': float(precision_score(y,pred,zero_division=0)),
      'recall': float(recall_score(y,pred,zero_division=0)),
      'brier': float(brier_score_loss(y,p)),
      'log_loss': float(log_loss(y,p,labels=[0,1])),
      'positive_rate': float(np.mean(pred)),
      'mean_probability': float(np.mean(p)),
      'evaluated_at_utc': datetime.now(timezone.utc).isoformat()
    }

def train_one(X, y, name, symbol, horizon, target):
    n = len(X)
    a, b = int(n*.60), int(n*.80)
    Xtr, ytr = X[:a], y[:a]
    Xcal, ycal = X[a:b], y[a:b]
    Xte, yte = X[b:], y[b:]
    candidates = {
      'hist_gradient_boosting': HistGradientBoostingClassifier(max_iter=250, learning_rate=.06, max_leaf_nodes=31, l2_regularization=1.0, random_state=42),
      'logistic_regression': make_pipeline(StandardScaler(), LogisticRegression(max_iter=1500, C=.5)),
      'random_forest': RandomForestClassifier(n_estimators=300, max_depth=10, min_samples_leaf=8, n_jobs=-1, random_state=42)
    }
    best = None
    for model_name, model in candidates.items():
        model.fit(Xtr, ytr)
        cal = fit_calibrator(model, Xcal, ycal)
        # Select the champion using the calibration/validation period only.
        p_val = calibrated_predict(model, cal, Xcal)
        m_val = metrics(ycal, p_val)
        if best is None or m_val['brier'] < best['validation_metrics']['brier']:
            best = {'model_name': model_name, 'model': model, 'cal': cal, 'validation_metrics': m_val}
    p_test = calibrated_predict(best['model'], best['cal'], Xte)
    m_test = metrics(yte, p_test)
    stem = f'{symbol}_{horizon}_{target}'
    joblib.dump({'model': best['model'], 'calibrator': best['cal']}, MODEL_DIR/f'{stem}.joblib')
    meta = {'symbol':symbol,'horizon':horizon,'target':target,'model_name':best['model_name'],'validation_metrics':best['validation_metrics'],'holdout_metrics':m_test,'created_at':datetime.now(timezone.utc).isoformat(),'feature_count':X.shape[1]}
    (MODEL_DIR/f'{stem}.json').write_text(json.dumps(meta,indent=2))
    return meta

def load_model(symbol,horizon,target):
    stem=f'{symbol}_{horizon}_{target}'
    path=MODEL_DIR/f'{stem}.joblib'
    if not path.exists(): return None
    return joblib.load(path)
