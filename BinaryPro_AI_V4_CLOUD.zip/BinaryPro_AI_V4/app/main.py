from pathlib import Path
import json, pandas as pd, numpy as np
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from .db import Base, engine, SessionLocal
from .schema import Tick
from .config import DEFAULT_SYMBOL, DEFAULT_HORIZON, MIN_SIGNAL_PROBABILITY, MIN_TRAIN_SAMPLES
from .features import build_features
from .modeling import load_model, calibrated_predict

app=FastAPI(title='BinaryPro AI Analyzer V4')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=False, allow_methods=['*'], allow_headers=['*'])
Base.metadata.create_all(engine)
STATIC=Path(__file__).resolve().parent.parent/'static'

@app.get('/health')
def health():
    return {'ok': True, 'service': 'binarypro-ai-v4'}

@app.get('/')
def index(): return FileResponse(STATIC/'index.html')

@app.get('/api/status')
def status(symbol:str=DEFAULT_SYMBOL,horizon:int=DEFAULT_HORIZON):
    with SessionLocal() as s:
        count=s.query(Tick).filter(Tick.symbol==symbol).count()
        last=s.query(Tick).filter(Tick.symbol==symbol).order_by(Tick.epoch.desc()).first()
    models=[]
    for target in ['rise_fall','over_under','even_odd','matches_differs']:
        p=Path('models')/f'{symbol}_{horizon}_{target}.json'
        if p.exists(): models.append(json.loads(p.read_text()))
    return {'symbol':symbol,'horizon':horizon,'tick_count':count,'last_price':last.price if last else None,'last_epoch':last.epoch if last else None,'models':models}

@app.get('/api/signal')
def signal(symbol:str=DEFAULT_SYMBOL,horizon:int=DEFAULT_HORIZON,target:str='rise_fall'):
    with SessionLocal() as s:
        rows=s.query(Tick).filter(Tick.symbol==symbol).order_by(Tick.epoch.desc()).limit(700).all()
    if len(rows)<200: return {'status':'WAIT','reason':'Not enough recent ticks','sample':len(rows)}
    rows=list(reversed(rows)); df=pd.DataFrame([{'symbol:r.symbol' if False else 'symbol':r.symbol,'epoch':r.epoch,'price':r.price,'last_digit':r.last_digit} for r in rows])
    F,_=build_features(df,100)
    model=load_model(symbol,horizon,target)
    if model is None: return {'status':'WAIT','reason':'No trained model','sample':len(F)}
    x=F.drop(columns=['symbol']).tail(1).astype(float).values
    p=float(calibrated_predict(model['model'],model['calibrator'],x)[0])
    direction='CLASS 1' if p>=0.5 else 'CLASS 0'; conf=max(p,1-p)
    status='SIGNAL' if conf>=MIN_SIGNAL_PROBABILITY and len(F)>=MIN_TRAIN_SAMPLES else 'WAIT'
    return {'status':status,'target':target,'probability':p,'confidence':conf,'direction':direction,'sample':len(F),'horizon':horizon,'symbol':symbol}

@app.get('/api/history')
def history(symbol:str=DEFAULT_SYMBOL,limit:int=500):
    with SessionLocal() as s: rows=s.query(Tick).filter(Tick.symbol==symbol).order_by(Tick.epoch.desc()).limit(min(limit,2000)).all()
    return [{'epoch':r.epoch,'price':r.price,'digit':r.last_digit} for r in reversed(rows)]
