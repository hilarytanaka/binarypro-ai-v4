import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./data/binarypro.db')
DERIV_WS_URL = os.getenv('DERIV_WS_URL', 'wss://ws.binaryws.com/websockets/v3')
DEFAULT_SYMBOL = os.getenv('DEFAULT_SYMBOL', 'R_75')
DEFAULT_HORIZON = int(os.getenv('DEFAULT_HORIZON', '5'))
MIN_SIGNAL_PROBABILITY = float(os.getenv('MIN_SIGNAL_PROBABILITY', '0.70'))
MIN_TRAIN_SAMPLES = int(os.getenv('MIN_TRAIN_SAMPLES', '1000'))
