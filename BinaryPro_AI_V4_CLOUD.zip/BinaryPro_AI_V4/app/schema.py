from datetime import datetime
from sqlalchemy import BigInteger, Float, Integer, String, DateTime, Index
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

class Tick(Base):
    __tablename__ = 'ticks'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    epoch: Mapped[int] = mapped_column(BigInteger, index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    price: Mapped[float] = mapped_column(Float)
    last_digit: Mapped[int] = mapped_column(Integer)
    __table_args__ = (Index('ix_ticks_symbol_epoch', 'symbol', 'epoch', unique=True),)

class Prediction(Base):
    __tablename__ = 'predictions'
    id: Mapped[int] = mapped_column(primary_key=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    horizon: Mapped[int] = mapped_column(Integer)
    target: Mapped[str] = mapped_column(String(32))
    predicted_class: Mapped[int] = mapped_column(Integer)
    probability: Mapped[float] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class Metric(Base):
    __tablename__ = 'model_metrics'
    id: Mapped[int] = mapped_column(primary_key=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    horizon: Mapped[int] = mapped_column(Integer)
    target: Mapped[str] = mapped_column(String(32))
    model_name: Mapped[str] = mapped_column(String(64))
    metrics_json: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
