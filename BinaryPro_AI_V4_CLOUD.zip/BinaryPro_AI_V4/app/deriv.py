import asyncio, json, time
from datetime import datetime, timezone
import websockets
from .config import DERIV_WS_URL

async def request(payload):
    async with websockets.connect(DERIV_WS_URL, ping_interval=20, ping_timeout=20) as ws:
        await ws.send(json.dumps(payload))
        while True:
            msg=json.loads(await ws.recv())
            if 'error' in msg: raise RuntimeError(msg['error'].get('message','Deriv API error'))
            if msg.get('msg_type') in ('history','tick','proposal','authorize'): return msg

def fetch_history(symbol, count=5000, start=None, end=None):
    p={'ticks_history':symbol,'style':'ticks','adjust_start_time':1}
    if start is not None or end is not None:
        p['start']=int(start or 1); p['end']=int(end or int(time.time()))
    else: p['count']=int(count)
    return asyncio.run(request(p))

def parse_history(msg, symbol):
    h=msg.get('history',{})
    prices=h.get('prices',[]); times=h.get('times',[])
    return [{'symbol':symbol,'epoch':int(t),'timestamp':datetime.fromtimestamp(int(t),tz=timezone.utc),'price':float(p),'last_digit':int(str(p).replace('.','')[-1])} for t,p in zip(times,prices)]
