from fastapi import APIRouter, Query
from .deriv_market import DerivMarketData

router = APIRouter(prefix="/deriv", tags=["Deriv Market Data"])

@router.get("/candles")
async def deriv_candles(
    symbol: str = Query("1HZ100V"),
    granularity: int = Query(60, ge=1),
    count: int = Query(200, ge=1, le=5000),
):
    data = await DerivMarketData(symbol).historical_candles(granularity, count)
    return {
        "symbol": symbol,
        "granularity": granularity,
        "count": len(data),
        "candles": data.to_dict(orient="records"),
    }
