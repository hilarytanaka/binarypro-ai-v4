# Deploy BinaryPro AI V4 from Android

The project is cloud-ready for Render. You do not need Python or Docker on your Android phone.

## 1. Put this project on GitHub

On github.com, create a new repository, then upload the contents of this folder (not the ZIP file itself). GitHub's mobile website can upload files from your phone after extraction.

## 2. Deploy with Render

Go to Render and choose **New -> Blueprint**. Connect the GitHub repository containing this project. Render detects `render.yaml` and creates:

- the web dashboard
- a PostgreSQL database
- a background Deriv tick collector
- a scheduled model-retraining job

The web service listens on Render's supplied `PORT` through the Dockerfile.

## 3. First data cycle

The collector bootstraps each configured symbol with historical ticks, then keeps collecting live ticks. The first model training job may return "not enough ticks" until the database reaches the minimum training size. The scheduled retraining job will try again every six hours.

## 4. Open on Android

When Render shows the web service as **Live**, open its HTTPS URL in Chrome. Add it to your home screen if you want it to behave like an app.

## Important

The system reports measured probabilities and test metrics. It does not promise or manufacture an 80-99% win rate. The model holdout period is kept separate from model selection in V4. Verify exact Deriv contract settlement and payout rules before using any output for real-money decisions.
