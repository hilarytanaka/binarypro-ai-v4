-- Optional production hardening when using TimescaleDB.
CREATE EXTENSION IF NOT EXISTS timescaledb;
-- After the SQLAlchemy table exists:
-- SELECT create_hypertable('ticks','timestamp', if_not_exists => TRUE);
-- CREATE INDEX IF NOT EXISTS ix_ticks_symbol_timestamp ON ticks(symbol,timestamp DESC);
